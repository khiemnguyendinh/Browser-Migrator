# Success Metrics & KPI

## Phase A — Decision Gate Metrics

Phase A được coi là **THÀNH CÔNG** và mở khóa Phase C khi đạt đủ các metric sau:

### 1. Technical Validation (Bắt buộc)

| Mã | Metric | Target | Cách đo |
|---|---|---|---|
| TV-01 | Keychain decryption thành công | 100% trên 3 máy test | Manual test |
| TV-02 | Cookie session preservation | User không phải login lại Gmail/Facebook | Manual test |
| TV-03 | Password migration accuracy | 100% passwords readable ở browser đích | Count diff |
| TV-04 | Migration time per profile | < 60s cho profile 500MB | Benchmark |
| TV-05 | Zero data loss | Backup + rollback hoạt động 100% | Integration test |

### 2. Quality Metrics (Bắt buộc)

| Mã | Metric | Target |
|---|---|---|
| QM-01 | Unit test coverage | ≥ 80% cho core modules (M02-M05) |
| QM-02 | Integration test pass rate | 100% trên 3 cặp browser (Chrome↔Edge, Chrome↔Brave, Edge↔Cốc Cốc) |
| QM-03 | Critical bugs | 0 |
| QM-04 | Code review pass rate | 100% module qua review của Claude Code |

### 3. Coverage Metrics

| Browser | Read | Write | Status |
|---|---|---|---|
| Chrome | Required | Required | P0 |
| Edge | Required | Required | P0 |
| Brave | Required | Required | P0 |
| Cốc Cốc | Required | Required | P0 |
| Arc | Required | Required | P1 |
| Comet | Optional | Optional | P2 |
| Vivaldi | Optional | Optional | P2 |
| Opera | Optional | Optional | P2 |

**Phase A pass:** 4/4 P0 browsers hoạt động cả read + write.

## Phase C — Future Metrics

Sau khi pass Phase A, các metrics cho Phase C (Open-Source GUI):

### 4. Adoption Metrics (90 ngày sau launch)

| Mã | Metric | Target Conservative | Target Stretch |
|---|---|---|---|
| AM-01 | GitHub Stars | 200 | 1,000 |
| AM-02 | Downloads | 1,000 | 10,000 |
| AM-03 | Product Hunt rank | Top 10 daily | Top 3 daily |
| AM-04 | HN front page | Yes (>100 points) | Yes (>500 points) |

### 5. Marketing Funnel Metrics

| Mã | Metric | Target |
|---|---|---|
| MF-01 | Landing page visitors | 5,000 / 90 ngày |
| MF-02 | Tool downloads | 1,000 |
| MF-03 | Email capture (lead magnet) | 200-300 |
| MF-04 | Conversion từ email → Kstudy course awareness | 30% (60-90 click) |
| MF-05 | YouTube video về tool | 3-5 videos, mỗi video > 5k views |

### 6. Authority Metrics (Cho Personal Brand)

| Mã | Metric | Cách đo |
|---|---|---|
| AU-01 | Tech blog posts về CPM | 2-3 bài (Medium/Dev.to) |
| AU-02 | Backlinks về Kstudy | 10+ |
| AU-03 | Speaking opportunity | 1+ tech talk/podcast invitation |

## 7. Quy trình Review

- **Daily standup (Phase A):** Khiêm + Claude Code update progress mỗi sáng.
- **Weekly review:** Cuối tuần check WBS, milestone.
- **Phase A retrospective:** Sau 2 tuần, đánh giá toàn diện trước khi quyết định Phase C.
- **Phase C decision:** Dựa trên TV + QM metrics. Pass = go. Fail = dừng hoặc pivot.
