# User Personas & Use Cases

## 1. Primary Personas

### Persona 1: Power Marketer (Khiêm — Chính)
- **Bối cảnh:** CEO Kstudy, dùng 3-5 browser cho các mục đích khác nhau.
- **Pain:** Mỗi lần test browser mới, mất 2-3 giờ setup lại extensions, login, autofill.
- **Goal:** Thử browser mới trong < 5 phút, không gián đoạn workflow.
- **Frequency:** 5-10 lần/năm.

### Persona 2: Multi-Account Operator (Team SAMA)
- **Bối cảnh:** Team chạy nhiều account YouTube/social, mỗi account 1 profile.
- **Pain:** Khi đổi máy hoặc browser, phải migrate hàng chục profiles.
- **Goal:** Migrate batch nhiều profile cùng lúc.
- **Frequency:** Hàng tháng khi onboard nhân sự mới.

### Persona 3: Developer (Phase C target)
- **Bối cảnh:** Lập trình viên dùng Arc/Comet làm dev browser, Chrome cho personal.
- **Pain:** Devtools profile khác personal profile, khó tách biệt.
- **Goal:** Nhanh chóng clone/sync profile cho từng context.

## 2. Use Cases — Phase A

### UC-01: Migrate Single Profile (Happy Path)

**Actor:** Power Marketer
**Precondition:**
- Cả browser nguồn và đích đã cài.
- User có quyền admin.

**Main Flow:**
1. User chạy `cpm migrate`.
2. System scan và hiển thị danh sách browsers + profiles.
3. User chọn nguồn: Chrome → Default.
4. User chọn đích: Edge → (tạo Default mới).
5. System hiển thị thống kê: 247 bookmarks, 89 passwords, 1.2GB cookies.
6. User confirm.
7. System backup Edge profile cũ (nếu có).
8. System đóng Edge process (nếu đang chạy).
9. System migrate từng module: bookmarks → history → autofill → cookies → passwords.
10. System verify.
11. System hiển thị report success.

**Postcondition:** User mở Edge, đăng nhập sẵn các tài khoản, autofill hoạt động.

### UC-02: Migrate với Existing Profile (Conflict)

**Actor:** Power Marketer
**Variant của UC-01.**

**Main Flow:**
1-3. Như UC-01.
4. User chọn đích: Edge → Default (đã có data).
5. System cảnh báo: "Profile Default ở Edge đã có 50 bookmarks và 12 passwords."
6. User chọn 1 trong 3 options:
   - **Overwrite:** ghi đè (system backup trước).
   - **Merge:** gộp (deduplicate by URL/domain).
   - **New profile:** tạo Profile 1 mới ở Edge.
7. System thực thi theo lựa chọn.

### UC-03: Rollback After Migration

**Actor:** Power Marketer
**Trigger:** User phát hiện migration bị lỗi.

**Main Flow:**
1. User chạy `cpm history` để xem các backup gần nhất.
2. System list: `[2026-05-01_14-30-22] Edge ← Chrome (Default)`.
3. User chạy `cpm rollback 2026-05-01_14-30-22`.
4. System xác nhận.
5. System đóng Edge.
6. System restore từ backup.
7. System verify.

### UC-04: List & Inspect (No Migration)

**Actor:** Developer (curious user)
**Goal:** Xem có gì trong profile mà không migrate.

**Main Flow:**
1. User chạy `cpm inspect --browser chrome --profile Default`.
2. System hiển thị:
   - Số lượng bookmarks (tree structure).
   - Số lượng passwords (chỉ count, không show value).
   - Số lượng cookies theo domain.
   - Extensions list.
   - Total size.

### UC-05: Cleanup Old Backups

**Actor:** Power Marketer
**Trigger:** Disk space cảnh báo.

**Main Flow:**
1. User chạy `cpm cleanup --older-than 30d`.
2. System list các backup > 30 ngày.
3. User confirm.
4. System xóa.

## 3. CLI Command Map

```
cpm                          # Help mặc định
cpm list                     # List browsers + profiles
cpm inspect <browser>        # Xem chi tiết profile
cpm migrate                  # Interactive migration
cpm migrate --from X --to Y  # Direct migration
cpm history                  # List backup history
cpm rollback <backup_id>     # Rollback
cpm cleanup --older-than 30d # Xóa backup cũ
cpm version                  # Version info
cpm doctor                   # Health check (Keychain access, browser detection)
```

## 4. Error Scenarios

| Mã | Tình huống | Hành xử của system |
|---|---|---|
| E-01 | Browser đích đang chạy | Yêu cầu user đóng, hoặc auto-close có confirm |
| E-02 | Keychain access bị từ chối | Hướng dẫn user grant permission qua System Settings |
| E-03 | Disk đầy | Thông báo + dừng, không partial write |
| E-04 | Source profile corrupt | Fail fast, log lỗi, không migrate |
| E-05 | Browser version không support | Cảnh báo, hỏi user có muốn proceed (best-effort) |
| E-06 | User Ctrl+C giữa chừng | Auto-rollback về trạng thái backup |
