# Data Flow Diagram

## 1. High-Level Data Flow

```
┌─────────────────┐                              ┌─────────────────┐
│  Source Browser │                              │  Target Browser │
│   Chrome        │                              │      Edge       │
└────────┬────────┘                              └────────▲────────┘
         │                                                │
         │ Read                                           │ Write
         │                                                │
┌────────▼────────────────────────────────────────────────┴────────┐
│                                                                  │
│                      CPM Migration Engine                        │
│                                                                  │
│  ┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────────┐           │
│  │ Reader  │──▶│Decrypter│──▶│Transform│──▶│ Encrypt │           │
│  │  (M02)  │   │  (M03)  │   │  (M04)  │   │  (M03)  │           │
│  └─────────┘   └─────────┘   └─────────┘   └────┬────┘           │
│       │             ▲                            │                │
│       │             │                            ▼                │
│       │       ┌─────┴─────┐                ┌─────────┐            │
│       │       │  Keychain │                │  Writer │            │
│       │       │   Access  │                │   (M05) │            │
│       │       └───────────┘                └─────────┘            │
│       │                                                           │
│       ▼                                                           │
│  ┌─────────┐                                                      │
│  │ Backup  │ ──▶ ~/CPM_Backups/{timestamp}/                       │
│  │  (M07)  │                                                      │
│  └─────────┘                                                      │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

## 2. Detailed Data Flow per Data Type

### 2.1 Bookmarks (Plaintext JSON)

```
Source: ~/Library/Application Support/Google/Chrome/Default/Bookmarks
        (JSON file, plaintext)
   │
   ▼
Read JSON → Parse tree structure → Validate
   │
   ▼
Transform (rename source-specific fields if any)
   │
   ▼
Write to: ~/Library/Application Support/Microsoft Edge/Default/Bookmarks
          (atomic write via .tmp + rename)
```

### 2.2 History (SQLite)

```
Source DB: Default/History
Tables: urls, visits, downloads, keyword_search_terms
   │
   ▼
SELECT all rows (parameterized) → in-memory list
   │
   ▼
Transform: adjust timestamp format if needed
   │
   ▼
Target DB: Default/History (Edge)
   - Open with sqlite3
   - BEGIN TRANSACTION
   - INSERT OR REPLACE rows
   - COMMIT
```

### 2.3 Cookies (SQLite + Encrypted Blobs)

```
Source DB: Default/Cookies
Encrypted column: encrypted_value (BLOB)
   │
   ▼
For each row:
  1. Read encrypted_value
  2. Detect version prefix (v10, v11)
  3. Get Chrome's master key from Keychain
     security find-generic-password -wa "Chrome Safe Storage"
  4. Derive AES key (PBKDF2-SHA1, salt="saltysalt", iter=1003)
  5. Decrypt with AES-128-CBC, IV=16 spaces
  6. Plaintext cookie value (in memory only)
   │
   ▼
Get Edge's master key from Keychain
  security find-generic-password -wa "Microsoft Edge Safe Storage"
   │
   ▼
For each cookie:
  1. Encrypt with Edge's key (same algorithm)
  2. Add "v10" prefix
  3. Build INSERT statement
   │
   ▼
Target DB: Default/Cookies (Edge)
  Atomic write via temp file
```

### 2.4 Saved Passwords (Login Data)

```
Source DB: Default/Login Data
Table: logins
Encrypted column: password_value (BLOB)
   │
   ▼
Same encryption flow as Cookies
   │
   ▼
For each login:
  - origin_url, username_value: plaintext
  - password_value: decrypt → re-encrypt with target key
   │
   ▼
Target DB: Default/Login Data (Edge)
```

### 2.5 Autofill (Web Data)

```
Source DB: Default/Web Data
Tables: autofill, autofill_profiles, credit_cards
   │
   ▼
Plaintext fields: copy direct
Encrypted fields (credit_cards.card_number_encrypted): same crypto flow
   │
   ▼
Target DB: Default/Web Data (Edge)
```

### 2.6 Extensions (Read-Only List)

```
Source: Default/Preferences (JSON)
        Default/Extensions/{extension_id}/...
   │
   ▼
Extract list of installed extension IDs + names
   │
   ▼
Phase A: Output report only (user manually reinstalls).
Phase C: Auto-open Chrome Web Store URLs in target browser.
```

## 3. Backup Flow

```
Pre-Migration State:
  ~/Library/Application Support/Microsoft Edge/Default/  (existing)
   │
   ▼
Step 1: Detect target profile path
   │
   ▼
Step 2: Create backup folder
  ~/CPM_Backups/2026-05-01_14-30-22_edge_default/
   │
   ▼
Step 3: tar.gz the entire profile folder
  tar -czf {backup_path}/profile.tar.gz {target_profile_path}
   │
   ▼
Step 4: Write metadata.json
  {
    "timestamp": "2026-05-01T14:30:22+07:00",
    "browser": "edge",
    "profile": "Default",
    "source_browser": "chrome",
    "source_profile": "Default",
    "size_bytes": 124567890,
    "checksum_sha256": "..."
  }
   │
   ▼
Step 5: Set permissions 600
   │
   ▼
Backup ready. Migration can proceed.
```

## 4. Rollback Flow

```
User Command: cpm rollback 2026-05-01_14-30-22
   │
   ▼
Step 1: Validate backup exists and checksum matches
   │
   ▼
Step 2: Detect if target browser is running, close it
   │
   ▼
Step 3: Move current target profile → temp folder
  (in case rollback fails, we can restore current state)
   │
   ▼
Step 4: Extract backup tar.gz to original location
   │
   ▼
Step 5: Verify extracted files (open SQLite DBs successfully)
   │
   ▼
Step 6: If verify OK: delete temp folder.
        If verify FAIL: restore from temp, fail rollback.
   │
   ▼
Done.
```

## 5. State Diagram — Migration Lifecycle

```
              ┌──────────┐
              │   IDLE   │
              └────┬─────┘
                   │ user runs migrate
                   ▼
              ┌──────────┐
              │ DETECTING│
              └────┬─────┘
                   │
                   ▼
              ┌──────────┐
              │VALIDATING│
              └────┬─────┘
                   │
       ┌───────────┴───────────┐
       │ pass                  │ fail
       ▼                       ▼
  ┌─────────┐            ┌──────────┐
  │BACKING_UP│           │  FAILED  │
  └────┬─────┘           └──────────┘
       │
       ▼
  ┌──────────┐
  │ READING  │
  └────┬─────┘
       │
       ▼
  ┌──────────┐
  │TRANSFORM │
  └────┬─────┘
       │
       ▼
  ┌──────────┐         ┌──────────┐
  │ WRITING  │ ───────▶│ROLLBACK  │ (if error)
  └────┬─────┘         └──────────┘
       │
       ▼
  ┌──────────┐
  │VERIFYING │
  └────┬─────┘
       │
       ▼
  ┌──────────┐
  │ SUCCESS  │
  └──────────┘
```
