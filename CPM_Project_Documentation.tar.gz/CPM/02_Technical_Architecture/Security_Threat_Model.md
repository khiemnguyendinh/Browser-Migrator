# Security Threat Model

## 1. Scope & Trust Boundaries

### 1.1 Trust Zones

```
┌────────────────────────────────────────────────┐
│           UNTRUSTED (External)                 │
│   - Network, Internet, Other apps              │
│   = NOT IN SCOPE FOR PHASE A                   │
└────────────────────────────────────────────────┘

┌────────────────────────────────────────────────┐
│           TRUSTED (User's Mac)                 │
│                                                 │
│   ┌─────────────────────────────────────────┐  │
│   │  Browser Profile Storage                │  │
│   │  ~/Library/Application Support/         │  │
│   │  (encrypted by macOS at rest)           │  │
│   └─────────────────────────────────────────┘  │
│                                                 │
│   ┌─────────────────────────────────────────┐  │
│   │  macOS Keychain                         │  │
│   │  (requires user authentication)         │  │
│   └─────────────────────────────────────────┘  │
│                                                 │
│   ┌─────────────────────────────────────────┐  │
│   │  CPM Process (RAM)                      │  │
│   │  - Decrypted secrets transient          │  │
│   │  - Cleared after migration              │  │
│   └─────────────────────────────────────────┘  │
│                                                 │
│   ┌─────────────────────────────────────────┐  │
│   │  CPM Backups (~/CPM_Backups/)           │  │
│   │  Permission 600                         │  │
│   └─────────────────────────────────────────┘  │
│                                                 │
└────────────────────────────────────────────────┘
```

### 1.2 Assets to Protect

| Asset | Sensitivity | Where Stored |
|---|---|---|
| Master encryption keys | CRITICAL | macOS Keychain |
| Decrypted passwords | CRITICAL | RAM only (transient) |
| Decrypted cookies | HIGH | RAM only (transient) |
| Browsing history | MEDIUM | Backup folder |
| Bookmarks | LOW | Backup folder |
| User preferences | LOW | Backup folder |

## 2. Threat Analysis (STRIDE)

### 2.1 Spoofing

| Mã | Threat | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| S-01 | Malicious binary giả mạo CPM | Low (Phase A) | High | Phase C: Code signing + notarization |
| S-02 | User chạy CPM giả từ phishing site | Low | Critical | Phase C: SHA256 checksum trên website |

### 2.2 Tampering

| Mã | Threat | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| T-01 | Kẻ tấn công sửa backup tar.gz | Low | High | Lưu SHA256 checksum trong metadata.json, verify khi rollback |
| T-02 | Race condition khi browser đang ghi | Medium | Medium | Force-close browser process trước migrate |
| T-03 | Crash giữa chừng làm corrupt target | Medium | Critical | Atomic file ops (tmp + rename), backup trước |

### 2.3 Repudiation

| Mã | Threat | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| R-01 | User claim "tool xóa data của tôi" | Low | Medium | Detailed logs với timestamp, backup mặc định, log không thể tắt |

### 2.4 Information Disclosure

| Mã | Threat | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| ID-01 | Logs chứa plaintext passwords | Medium nếu code sai | Critical | Sanitization layer ở M08, banned word list, code review |
| ID-02 | Backup chứa decrypted data | Low | Critical | Backup chỉ chứa file gốc đã encrypted, không decrypt khi backup |
| ID-03 | Memory dump leak secrets | Low | High | Clear sensitive vars sau khi dùng, dùng `bytearray` thay vì `str` cho passwords |
| ID-04 | Swap file chứa secrets | Low | High | macOS encrypts swap by default. Document cảnh báo. |
| ID-05 | Telemetry leak data (Phase C) | Medium | High | Phase A: ZERO telemetry. Phase C: opt-in, anonymized, no PII |

### 2.5 Denial of Service

| Mã | Threat | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| DoS-01 | Disk full khi backup → migrate fail | Medium | Medium | Pre-check disk space, abort sớm |
| DoS-02 | Profile quá lớn (>5GB) timeout | Low | Low | Streaming reads, không load all in memory |

### 2.6 Elevation of Privilege

| Mã | Threat | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| EoP-01 | Tool yêu cầu sudo không cần thiết | Low | Medium | KHÔNG bao giờ chạy sudo. Tất cả ops trong user space. |
| EoP-02 | Path traversal khi user input | Medium | High | Validate path, reject `..` và absolute path bên ngoài Library |

## 3. Security Controls

### 3.1 Mandatory Controls (Phase A)

**SC-01: Authentication Required for Keychain**
- CPM gọi `security find-generic-password` → macOS hiện dialog → user confirm.
- Không cache credentials. Mỗi lần migrate phải auth lại.

**SC-02: Sensitive Data Lifecycle**
```python
# BẮT BUỘC pattern khi xử lý secrets:
def decrypt_password(encrypted: bytes) -> str:
    plaintext = aes_decrypt(encrypted, key)
    try:
        # Use plaintext immediately
        re_encrypted = aes_encrypt(plaintext, target_key)
        return re_encrypted
    finally:
        # Overwrite memory (best-effort in Python)
        if isinstance(plaintext, bytearray):
            for i in range(len(plaintext)):
                plaintext[i] = 0
```

**SC-03: Logging Sanitization**
- M08 Logger có blacklist các keys: `password`, `cookie_value`, `encrypted_value`, `card_number`, `cvv`.
- Pre-process every log entry, replace matching keys với `[REDACTED]`.

**SC-04: File Permissions**
- Backup files: chmod 600.
- Logs: chmod 600.
- Verify trước khi ghi.

**SC-05: Browser Process Check**
- Trước khi migrate, dùng `ps aux | grep` để check browser process.
- Nếu đang chạy: cảnh báo + offer auto-kill (với confirm).

**SC-06: Atomic Operations**
- Tất cả file writes: `temp_path → fsync → rename(temp_path, final_path)`.
- Database operations: BEGIN TRANSACTION / COMMIT / ROLLBACK.

**SC-07: Input Validation**
- Browser names whitelist: chỉ accept `chrome`, `edge`, `brave`, `arc`, `coccoc`.
- Profile names: regex `^[a-zA-Z0-9 _-]+$`.
- Reject path traversal.

**SC-08: No Network**
- Phase A: ZERO network calls. Tool có thể chạy offline 100%.
- Code review check: grep cho `requests`, `urllib`, `httpx`, `socket` → must NOT exist.

### 3.2 Recommended Controls (Phase C)

- Code signing với Apple Developer ID.
- Notarization qua Apple's notary service.
- Optional encrypted backups (user provides passphrase).
- Update check qua GitHub Releases (HTTPS).
- Anonymous telemetry với explicit opt-in.

## 4. Security Test Plan

### 4.1 Mandatory Tests (Phase A)

| Test ID | Mô tả | Method |
|---|---|---|
| ST-01 | No plaintext secrets in logs | grep logs sau full run, find "password=", "cookie_value=" → must be empty |
| ST-02 | Backup integrity | SHA256 verify backup file matches metadata |
| ST-03 | No network calls | Run with `nettop` monitoring, expect 0 connections |
| ST-04 | Permission check | Verify backup files have 600 |
| ST-05 | Atomic write | Kill process mid-write, verify target file not corrupted |
| ST-06 | Path traversal | Try `--profile ../../etc/passwd` → must reject |
| ST-07 | Memory leak | Run + check `ps` for sustained memory after migration |

### 4.2 Penetration Test Scenarios

- **Adversarial profile:** Tạo profile Chrome với SQL injection trong bookmark name → tool phải handle safely.
- **Symlink attack:** Replace target profile path với symlink → must detect và refuse.
- **Race condition:** Edit source profile DURING migration → tool phải lock hoặc detect.

## 5. Incident Response (Phase A)

Vì Phase A là internal tool, không có user-facing incident response. Nếu phát hiện bug nghiêm trọng:

1. Khiêm + Claude Code review log.
2. Identify root cause.
3. Patch + add regression test.
4. Notify team Kstudy nếu họ đã dùng.

## 6. Compliance Considerations

- **Apple App Store:** Không apply vì Phase A là personal tool.
- **GDPR/CCPA:** Tool không thu thập data, không apply.
- **Browser TOS:** CPM đọc/ghi file local của browser. Cần check TOS Chrome/Edge xem có cấm "third-party tools modify profile" không. Phase A: low risk vì internal use. Phase C: cần legal review.

## 7. Security Review Sign-Off

Trước khi release Phase A cho team Kstudy:
- [ ] All ST tests pass.
- [ ] Code review focus on M03 (Keychain) và M08 (Logger sanitization) bởi Claude Code.
- [ ] Manual penetration test 3 scenarios trên.
- [ ] Update threat model nếu phát hiện threat mới.
