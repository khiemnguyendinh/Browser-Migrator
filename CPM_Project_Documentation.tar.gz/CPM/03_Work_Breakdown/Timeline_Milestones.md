# Timeline & Milestones

## Phase A — 10-14 Working Days

### Sprint Plan

```
Week 1: Foundation + Core
Week 2: Integration + Testing + Release
```

### Daily Breakdown

#### Day 1 — Project Kickoff
**Goal:** Repo ready, team aligned.

- [ ] Khiêm: Tạo Git repo private trên GitHub.
- [ ] Antigravity: Clone repo, setup Python 3.11 venv.
- [ ] Antigravity: Install dependencies: `click`, `cryptography`, `rich`, `pytest`, `mypy`, `ruff`, `black`.
- [ ] Antigravity: Folder structure (src/, tests/, docs/).
- [ ] Antigravity: Pre-commit hooks setup.
- [ ] Claude Code: Initial spike trên M03 (Keychain) — verify khả thi `security` CLI.
- [ ] Claude Code: Document findings vào `05_Coordination/M03_spike_findings.md`.

**Milestone M0:** Repo + dev env ready, M03 feasibility confirmed.

#### Day 2-3 — Critical Path Start
**Goal:** M03 working prototype + M01/M07 done.

Day 2:
- [ ] Claude Code: M03 implementation (Keychain access + AES decrypt).
- [ ] Antigravity: M01 Browser Detector full implementation + tests.
- [ ] Antigravity: M07 Backup function (tar.gz + metadata).

Day 3:
- [ ] Claude Code: M03 re-encryption logic + memory hygiene.
- [ ] Claude Code: M03 unit tests.
- [ ] Antigravity: M07 Rollback + cleanup.
- [ ] Antigravity: M07 unit tests.

**Milestone M1:** M01 + M07 + M03 (decrypt path) DONE.

#### Day 4-5 — Reader & Logger
Day 4:
- [ ] Claude Code: M02 architecture + dataclasses + interface.
- [ ] Antigravity: M08 Logger structure + sanitizer.
- [ ] Antigravity: Code review M01, M07 by Claude Code.

Day 5:
- [ ] Claude Code: M02 SQLite reader (History, Web Data).
- [ ] Antigravity: M02 SQLite reader (Login Data, Cookies) under Claude Code guidance.
- [ ] Antigravity: M08 unit tests.
- [ ] Khiêm: Mid-week review session.

**Milestone M2:** M08 done, M02 50%, M03 done.

#### Day 6-7 — Reader done + Transformer
Day 6:
- [ ] Claude Code: M02 JSON readers (Bookmarks, Preferences).
- [ ] Claude Code: M04 architect — adapter base class + transform contracts.
- [ ] Antigravity: M04 Chrome adapter + Edge adapter.

Day 7:
- [ ] Antigravity: M04 Brave + Cốc Cốc + Arc adapters.
- [ ] Claude Code: M02 unit tests + integration with M03.
- [ ] Claude Code: M05 architect.

**Milestone M3:** M02 + M04 done. Reader path E2E tested với mock data.

#### Day 8 — Writer + Orchestrator
- [ ] Claude Code: M05 Profile Writer (atomic SQLite + JSON writes).
- [ ] Claude Code: Orchestrator state machine + error handling.
- [ ] Antigravity: M05 process detection + close logic.
- [ ] Antigravity: Start M06 CLI skeleton.

**Milestone M4:** M05 + Orchestrator done. Có thể chạy migration thực tế Chrome → Edge từ Python REPL.

#### Day 9 — CLI + Integration
- [ ] Antigravity: M06 CLI all commands (list, inspect, migrate, history, rollback, cleanup, doctor).
- [ ] Antigravity: Progress bars, UX polish.
- [ ] Claude Code: Code review M04, M05, M06.
- [ ] Both: First E2E test Chrome → Edge.

**Milestone M5:** First successful E2E migration.

#### Day 10 — Test, Polish, Release
- [ ] Both: E2E tests cho 4 cặp browser P0.
- [ ] Both: Security tests ST-01 → ST-07.
- [ ] Both: Performance benchmark.
- [ ] Antigravity: Documentation finalize (README user guide, troubleshooting).
- [ ] Bug fixes.
- [ ] Khiêm: UAT trên máy thật.
- [ ] Khiêm: Phase A retrospective.
- [ ] Khiêm: Phase C go/no-go decision.

**Milestone M6 (RELEASE):** Phase A v0.1 release nội bộ.

### Buffer Days (11-14)

Nếu trễ kế hoạch, buffer dùng cho:
- Day 11-12: Hoàn thiện scope chưa xong.
- Day 13: Bug fix + retest.
- Day 14: Release + retrospective.

## Phase C — 6-8 Tuần (Sau Khi Phase A Pass)

### High-Level Roadmap (chi tiết hóa khi Phase A done)

```
Week 1-2:  GUI development (Electron hoặc SwiftUI)
Week 3:    Code signing + Notarization
Week 4:    Cross-browser comprehensive testing
Week 5:    Landing page + Documentation site
Week 6:    Beta release với 10-20 testers
Week 7:    Bug fixes from beta + final polish
Week 8:    Public launch (Product Hunt + HN + Reddit + YouTube)
```

## Milestones Overview

| ID | Tên | Ngày | Deliverable |
|---|---|---|---|
| M0 | Project Setup | Day 1 | Repo + env + spike findings |
| M1 | Foundation Modules | Day 3 | M01, M03 (decrypt), M07 |
| M2 | Logger + Reader 50% | Day 5 | M08, M02 partial |
| M3 | Reader + Transformer | Day 7 | M02, M04 done |
| M4 | Writer + Orchestrator | Day 8 | M05, Orchestrator |
| M5 | First E2E Success | Day 9 | Chrome → Edge migrate works |
| M6 | RELEASE v0.1 | Day 10 | All P0 pass, UAT pass |

## Tracking & Reporting

### Daily Status Log Format

File: `05_Coordination/daily_log.md`

```markdown
## YYYY-MM-DD

### Antigravity
- DONE: [tasks]
- TODAY: [tasks]
- BLOCKERS: [items]

### Claude Code
- REVIEWED: [PRs]
- TODO: [tasks]
- DECISIONS: [architectural decisions made]

### Khiêm
- [Notes if any]
```

### Weekly Review Template

End of Week 1 và Week 2:
- Burn-down: completed tasks vs planned.
- Blockers reviewed.
- Risk re-assessment.
- Adjust timeline nếu cần.
