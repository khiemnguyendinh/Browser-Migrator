# Work Breakdown Structure (WBS)

## Phase A — CLI MVP (2 tuần / 10 working days)

```
CPM Phase A
│
├── 1.0 Project Setup (Day 1)
│   ├── 1.1 Repo init, gitignore, README
│   ├── 1.2 Python venv, pyproject.toml, dependencies
│   ├── 1.3 Folder structure
│   ├── 1.4 Pre-commit hooks (black, ruff, mypy)
│   └── 1.5 CI skeleton (GitHub Actions cho Phase C)
│
├── 2.0 Core Modules (Day 2-7)
│   ├── 2.1 M01 - Browser Detector
│   │   ├── 2.1.1 Define BrowserInfo dataclass
│   │   ├── 2.1.2 Detection logic per browser
│   │   ├── 2.1.3 Profile enumeration
│   │   └── 2.1.4 Unit tests
│   │
│   ├── 2.2 M02 - Profile Reader
│   │   ├── 2.2.1 SQLite reader (History, Login Data, Cookies, Web Data)
│   │   ├── 2.2.2 JSON reader (Bookmarks, Preferences, Local State)
│   │   ├── 2.2.3 ProfileSnapshot dataclass
│   │   ├── 2.2.4 Streaming for large files
│   │   └── 2.2.5 Unit tests
│   │
│   ├── 2.3 M03 - Keychain Decryptor [CRITICAL]
│   │   ├── 2.3.1 Keychain access via security CLI
│   │   ├── 2.3.2 PBKDF2 key derivation
│   │   ├── 2.3.3 AES-128-CBC decrypt
│   │   ├── 2.3.4 Re-encrypt với target key
│   │   ├── 2.3.5 Memory hygiene (clear secrets)
│   │   ├── 2.3.6 Unit tests
│   │   └── 2.3.7 Security review
│   │
│   ├── 2.4 M04 - Data Transformer
│   │   ├── 2.4.1 Adapter base class
│   │   ├── 2.4.2 Chrome adapter
│   │   ├── 2.4.3 Edge adapter
│   │   ├── 2.4.4 Brave adapter
│   │   ├── 2.4.5 Cốc Cốc adapter
│   │   ├── 2.4.6 Arc adapter
│   │   └── 2.4.7 Unit tests
│   │
│   ├── 2.5 M05 - Profile Writer
│   │   ├── 2.5.1 Atomic SQLite writer
│   │   ├── 2.5.2 Atomic JSON writer
│   │   ├── 2.5.3 Permission setting
│   │   ├── 2.5.4 Browser process detection + close
│   │   └── 2.5.5 Unit tests
│   │
│   ├── 2.6 M07 - Backup & Rollback
│   │   ├── 2.6.1 tar.gz backup
│   │   ├── 2.6.2 Metadata.json + checksum
│   │   ├── 2.6.3 Restore logic
│   │   ├── 2.6.4 Cleanup old backups
│   │   └── 2.6.5 Unit tests
│   │
│   └── 2.7 M08 - Logger
│       ├── 2.7.1 Structured logging (JSON)
│       ├── 2.7.2 Sensitive data sanitizer
│       ├── 2.7.3 File rotation
│       └── 2.7.4 Unit tests
│
├── 3.0 Orchestrator (Day 8)
│   ├── 3.1 Migration Engine class
│   ├── 3.2 State machine
│   ├── 3.3 Error handling + auto-rollback
│   └── 3.4 Integration tests
│
├── 4.0 CLI Interface — M06 (Day 9)
│   ├── 4.1 Click app skeleton
│   ├── 4.2 list command
│   ├── 4.3 inspect command
│   ├── 4.4 migrate command (interactive + flags)
│   ├── 4.5 history command
│   ├── 4.6 rollback command
│   ├── 4.7 cleanup command
│   ├── 4.8 doctor command
│   ├── 4.9 Progress bars (rich)
│   └── 4.10 Help text + UX polish
│
├── 5.0 Testing & Validation (Day 10)
│   ├── 5.1 End-to-end test: Chrome → Edge
│   ├── 5.2 End-to-end test: Chrome → Brave
│   ├── 5.3 End-to-end test: Edge → Cốc Cốc
│   ├── 5.4 Security tests (ST-01 to ST-07)
│   ├── 5.5 Performance benchmark
│   ├── 5.6 Bug fixes
│   └── 5.7 Phase A retrospective
│
└── 6.0 Documentation (parallel với 4.0-5.0)
    ├── 6.1 User README (how to install, use)
    ├── 6.2 Developer guide
    ├── 6.3 Troubleshooting FAQ
    └── 6.4 CHANGELOG
```

## Effort Estimation

| Module | Effort (hours) | Owner |
|---|---|---|
| 1.0 Project Setup | 4 | Antigravity |
| 2.1 M01 Browser Detector | 6 | Antigravity |
| 2.2 M02 Profile Reader | 12 | Claude Code (lead) + Antigravity (impl) |
| 2.3 M03 Keychain Decryptor | 16 | Claude Code [SOLE OWNER] |
| 2.4 M04 Data Transformer | 14 | Claude Code (architect) + Antigravity (adapters) |
| 2.5 M05 Profile Writer | 12 | Claude Code (lead) + Antigravity (impl) |
| 2.6 M07 Backup & Rollback | 8 | Antigravity |
| 2.7 M08 Logger | 6 | Antigravity |
| 3.0 Orchestrator | 8 | Claude Code [SOLE OWNER] |
| 4.0 M06 CLI | 10 | Antigravity |
| 5.0 Testing | 12 | Both (50/50) |
| 6.0 Documentation | 6 | Antigravity |
| **Total** | **114 hours** | — |

**Ratio:** Claude Code ~46h (40%) / Antigravity ~52h (46%) / Shared ~16h (14%) → khớp với mục tiêu 60/40 (Claude Code lead architecture + critical modules dù số giờ ít hơn, vì việc khó hơn).

## Phase A Timeline (10 working days)

| Day | Khiêm | Claude Code | Antigravity | Milestone |
|---|---|---|---|---|
| 1 | Kickoff, review docs | Architect M03 spike | Setup repo, env | Project ready |
| 2 | Available for review | M03 prototype | M01 implement | M01 done |
| 3 | Available for review | M03 implement | M07 implement | M07 done |
| 4 | Available for review | M02 architect | M01/M07 tests | Backup tested |
| 5 | Mid-week review | M02 implement | M08 implement | M08 done |
| 6 | Available for review | M04 architect | M02 tests + M04 adapters | M02 partial |
| 7 | Available for review | M05 architect + impl | M04 adapters cont. | M04, M05 partial |
| 8 | Available for review | Orchestrator + integration | M05 tests + CLI start | Integration ready |
| 9 | Manual UAT | Code review all | M06 CLI complete | E2E ready |
| 10 | Phase A retro + Phase C decision | Bug fixes | Docs + bug fixes | RELEASE v0.1 |

## Critical Path

```
Day 1 → Setup
  ↓
Day 2-3 → M03 (Keychain) [BLOCKING]
  ↓
Day 4-6 → M02 (Reader) [BLOCKING for M04, M05]
  ↓
Day 6-7 → M04 (Transformer) + M05 (Writer)
  ↓
Day 8 → Orchestrator
  ↓
Day 9 → CLI integration
  ↓
Day 10 → Test + Release
```

**Parallel opportunities:**
- M01, M07, M08 độc lập với critical path → Antigravity làm song song trong Day 2-5.
- Documentation chạy song song với code Day 8-10.

## Risk-Adjusted Buffer

Effort thực tế = Estimated × 1.3 (buffer 30%) = **148 hours ~ 18.5 working days**.

→ Nếu chạy đúng kế hoạch 10 ngày là aggressive. Acceptable target: **10-14 ngày**.
