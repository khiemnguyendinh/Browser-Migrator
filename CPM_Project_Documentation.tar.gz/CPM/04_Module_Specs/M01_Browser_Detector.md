# M01 — Browser Detector

**Owner:** Antigravity
**Reviewer:** Claude Code
**Priority:** P0
**Estimated Effort:** 6 hours

## 1. Mục đích

Phát hiện tự động các Chromium browser đã cài trên macOS, enumerate profiles của mỗi browser, trả về metadata.

## 2. Public API

```python
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

@dataclass(frozen=True)
class ProfileInfo:
    name: str                    # "Default", "Profile 1", etc.
    path: Path                   # Absolute path to profile folder
    display_name: str            # User-set name from Preferences
    size_bytes: int
    last_modified: float         # Unix timestamp

@dataclass(frozen=True)
class BrowserInfo:
    id: str                      # "chrome", "edge", "brave", "arc", "coccoc"
    display_name: str            # "Google Chrome"
    version: Optional[str]       # "120.0.6099.71" if detectable
    user_data_path: Path         # Root path to User Data folder
    profiles: List[ProfileInfo]
    is_running: bool             # Currently has running process

def detect_all_browsers() -> List[BrowserInfo]:
    """Scan macOS for all installed Chromium browsers."""
    ...

def get_browser(browser_id: str) -> Optional[BrowserInfo]:
    """Get info for a specific browser by ID."""
    ...

def is_browser_running(browser_id: str) -> bool:
    """Check if browser process is currently running."""
    ...
```

## 3. Browser Registry

```python
SUPPORTED_BROWSERS = {
    "chrome": {
        "display_name": "Google Chrome",
        "user_data_path": "~/Library/Application Support/Google/Chrome",
        "process_name": "Google Chrome",
        "keychain_service": "Chrome Safe Storage",
        "app_path": "/Applications/Google Chrome.app",
    },
    "edge": {
        "display_name": "Microsoft Edge",
        "user_data_path": "~/Library/Application Support/Microsoft Edge",
        "process_name": "Microsoft Edge",
        "keychain_service": "Microsoft Edge Safe Storage",
        "app_path": "/Applications/Microsoft Edge.app",
    },
    "brave": {
        "display_name": "Brave",
        "user_data_path": "~/Library/Application Support/BraveSoftware/Brave-Browser",
        "process_name": "Brave Browser",
        "keychain_service": "Brave Safe Storage",
        "app_path": "/Applications/Brave Browser.app",
    },
    "arc": {
        "display_name": "Arc",
        "user_data_path": "~/Library/Application Support/Arc/User Data",
        "process_name": "Arc",
        "keychain_service": "Arc Safe Storage",
        "app_path": "/Applications/Arc.app",
    },
    "coccoc": {
        "display_name": "Cốc Cốc",
        "user_data_path": "~/Library/Application Support/Coccoc",
        "process_name": "CocCoc",
        "keychain_service": "CocCoc Safe Storage",
        "app_path": "/Applications/CocCoc.app",
    },
}
```

## 4. Detection Logic

1. Check `app_path` exists → browser installed.
2. Check `user_data_path` exists → has user data.
3. Read `Local State` JSON để detect profiles (key: `profile.info_cache`).
4. Fallback: scan folders matching pattern `Default` hoặc `Profile *`.
5. Get version từ `Info.plist` của app (`CFBundleShortVersionString`).
6. Check process running: `ps -ax -o comm | grep -i "{process_name}"`.

## 5. Edge Cases

- Browser cài qua Homebrew Cask (path khác).
- Browser portable / từ DMG không drag vào Applications.
- Multiple installations (e.g., Chrome + Chrome Canary).
- Profile folder rỗng (browser cài chưa chạy lần nào).
- User data path symlinked.

## 6. Tests

```python
def test_detect_chrome_when_installed():
    # Mock filesystem with Chrome installed
    ...

def test_detect_returns_empty_when_no_browsers():
    ...

def test_profile_enumeration_with_multiple_profiles():
    ...

def test_handles_missing_local_state_gracefully():
    ...

def test_is_running_detects_active_process():
    ...

def test_version_detection_from_plist():
    ...
```

Coverage target: ≥ 90%.
