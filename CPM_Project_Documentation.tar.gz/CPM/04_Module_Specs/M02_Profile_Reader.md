# M02 — Profile Reader

**Owner:** Claude Code (architect) + Antigravity (impl)
**Reviewer:** Claude Code
**Priority:** P0
**Estimated Effort:** 12 hours

## 1. Mục đích

Đọc toàn bộ profile data từ một browser source và build in-memory `ProfileSnapshot` object.

## 2. Public API

```python
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

@dataclass
class BookmarkNode:
    id: str
    name: str
    url: Optional[str]           # None nếu là folder
    type: str                    # "url" | "folder"
    date_added: int
    children: List['BookmarkNode'] = field(default_factory=list)

@dataclass
class HistoryEntry:
    url: str
    title: str
    visit_count: int
    typed_count: int
    last_visit_time: int

@dataclass
class CookieEntry:
    host_key: str
    name: str
    encrypted_value: bytes       # KHÔNG decrypt ở module này
    path: str
    expires_utc: int
    is_secure: bool
    is_httponly: bool
    samesite: int

@dataclass
class LoginEntry:
    origin_url: str
    username_value: str
    password_value_encrypted: bytes  # KHÔNG decrypt ở module này
    date_created: int

@dataclass
class AutofillEntry:
    name: str
    value: str
    count: int

@dataclass
class AddressProfile:
    guid: str
    full_name: str
    email: str
    phone: str
    street_address: str
    city: str
    state: str
    zip_code: str
    country_code: str

@dataclass
class ExtensionInfo:
    id: str
    name: str
    version: str
    enabled: bool

@dataclass
class ProfileSnapshot:
    source_browser_id: str
    source_profile_name: str
    bookmarks: BookmarkNode      # Root node
    history: List[HistoryEntry]
    cookies: List[CookieEntry]
    logins: List[LoginEntry]
    autofill: List[AutofillEntry]
    addresses: List[AddressProfile]
    extensions: List[ExtensionInfo]
    raw_preferences: Dict[str, Any]   # Full Preferences JSON

def read_profile(browser: BrowserInfo, profile_name: str) -> ProfileSnapshot:
    """Read full profile snapshot. Encrypted values stay encrypted."""
    ...
```

## 3. Implementation Strategy

### 3.1 SQLite Reads
- Use `sqlite3` stdlib.
- **CRITICAL:** Open in read-only mode: `sqlite3.connect(f"file:{path}?mode=ro", uri=True)`.
- Acquire shared lock to prevent corruption from running browser.

```python
def _read_history(profile_path: Path) -> List[HistoryEntry]:
    db_path = profile_path / "History"
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        cursor = conn.execute(
            "SELECT url, title, visit_count, typed_count, last_visit_time FROM urls"
        )
        return [HistoryEntry(*row) for row in cursor]
    finally:
        conn.close()
```

### 3.2 JSON Reads
- `json.load()` với encoding utf-8.
- Validate top-level keys exist trước khi parse.

### 3.3 Bookmarks Recursive Parse
Bookmarks file structure:
```json
{
  "roots": {
    "bookmark_bar": {...},
    "other": {...},
    "synced": {...}
  }
}
```
Build tree với DFS.

### 3.4 Encrypted Data
- Read encrypted blobs raw, KHÔNG decrypt ở module này.
- M03 (Decryptor) là module duy nhất chạm vào key/decrypt.

## 4. Error Handling

| Error | Handling |
|---|---|
| File not found | Skip với warning log, return empty list |
| SQLite locked (browser running) | Raise `BrowserRunningError` |
| Corrupted DB | Raise `CorruptedProfileError`, không partial read |
| Permission denied | Raise `PermissionError` với hướng dẫn fix |

## 5. Performance

- Streaming reads cho History (có thể > 100k rows): use cursor iterator, không fetchall().
- Memory limit: < 100MB cho 1 profile 1GB.
- Time limit: < 10s cho profile 500MB.

## 6. Tests

Use fixture data trong `tests/fixtures/profiles/`:
- Mini Chrome profile với 10 bookmarks, 100 history entries, 5 logins, 10 cookies.
- Empty profile (newly created).
- Corrupted profile (truncated SQLite).

```python
def test_read_full_profile_chrome():
    snapshot = read_profile(chrome_info, "Default")
    assert len(snapshot.history) == 100
    assert len(snapshot.bookmarks.children) > 0
    # Encrypted blobs are bytes, not strings
    assert all(isinstance(c.encrypted_value, bytes) for c in snapshot.cookies)

def test_read_locked_db_raises():
    # Simulate browser running
    with pytest.raises(BrowserRunningError):
        read_profile(...)

def test_corrupted_db_raises():
    ...

def test_empty_profile_returns_empty_collections():
    ...
```

Coverage target: ≥ 85%.
