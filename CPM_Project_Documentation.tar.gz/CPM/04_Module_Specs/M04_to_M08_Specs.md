# M04 — Data Transformer

**Owner:** Claude Code (architect) + Antigravity (per-browser adapters)
**Reviewer:** Claude Code
**Priority:** P0
**Estimated Effort:** 14 hours

## 1. Mục đích

Adapter pattern: chuyển đổi `ProfileSnapshot` từ format browser nguồn sang format browser đích, xử lý các edge cases và browser-specific fields.

## 2. Architecture

```python
from abc import ABC, abstractmethod

class BrowserAdapter(ABC):
    """Base adapter for browser-specific transformations."""
    
    browser_id: str
    
    @abstractmethod
    def transform_bookmarks(self, source: BookmarkNode) -> BookmarkNode:
        """Adjust bookmarks for this browser's format."""
    
    @abstractmethod
    def transform_preferences(self, source: dict) -> dict:
        """Strip incompatible fields, keep general settings."""
    
    @abstractmethod
    def filter_extensions(self, source: List[ExtensionInfo]) -> List[ExtensionInfo]:
        """Some extensions may not be available on target browser."""
    
    def transform_history(self, source: List[HistoryEntry]) -> List[HistoryEntry]:
        return source  # Default: no change
    
    def transform_cookies(self, source: List[CookieEntry]) -> List[CookieEntry]:
        return source  # Default: no change (re-encryption handled by Orchestrator)
    
    # ... v.v.

class ChromeAdapter(BrowserAdapter):
    browser_id = "chrome"
    # implementations...

class EdgeAdapter(BrowserAdapter):
    browser_id = "edge"
    # implementations...

class BraveAdapter(BrowserAdapter):
    browser_id = "brave"
    # Strip BAT-specific fields from preferences
    # ...

class CocCocAdapter(BrowserAdapter):
    browser_id = "coccoc"
    # Handle Cốc Cốc Coc Coc-specific fields (download manager, sidebar)
    # ...

class ArcAdapter(BrowserAdapter):
    browser_id = "arc"
    # Arc has different "Spaces" concept, map to profiles
    # ...

ADAPTERS: Dict[str, BrowserAdapter] = {
    "chrome": ChromeAdapter(),
    "edge": EdgeAdapter(),
    "brave": BraveAdapter(),
    "coccoc": CocCocAdapter(),
    "arc": ArcAdapter(),
}

def transform(
    snapshot: ProfileSnapshot,
    target_browser_id: str,
) -> ProfileSnapshot:
    """Apply target browser's adapter to transform snapshot."""
    adapter = ADAPTERS[target_browser_id]
    return ProfileSnapshot(
        source_browser_id=snapshot.source_browser_id,
        source_profile_name=snapshot.source_profile_name,
        bookmarks=adapter.transform_bookmarks(snapshot.bookmarks),
        history=adapter.transform_history(snapshot.history),
        cookies=adapter.transform_cookies(snapshot.cookies),
        logins=snapshot.logins,
        autofill=snapshot.autofill,
        addresses=snapshot.addresses,
        extensions=adapter.filter_extensions(snapshot.extensions),
        raw_preferences=adapter.transform_preferences(snapshot.raw_preferences),
    )
```

## 3. Browser-Specific Notes

| Browser | Đặc thù |
|---|---|
| Chrome | Baseline, không cần transform |
| Edge | Có Collections feature, không port được. Strip Edge-specific Preferences keys. |
| Brave | Có BAT (Basic Attention Token) wallet. Strip wallet fields. Brave Shields settings strip. |
| Cốc Cốc | Download manager, sidebar config. Strip nếu target không support. |
| Arc | "Spaces" thay vì profiles. Phase A: skip Arc bookmarks (incompatible structure), document warning. |

## 4. Tests

Per adapter:
- Round-trip test: Chrome adapter on Chrome data = identity.
- Cross-browser: Chrome → Edge transforms preferences correctly.
- Edge cases: Brave wallet fields are stripped.

Coverage: ≥ 80%.

---

# M05 — Profile Writer

**Owner:** Claude Code (architect) + Antigravity (impl)
**Reviewer:** Claude Code
**Priority:** P0
**Estimated Effort:** 12 hours

## 1. Mục đích

Ghi `ProfileSnapshot` (đã transform) vào browser đích, đảm bảo atomic operations và browser process management.

## 2. Public API

```python
def write_profile(
    snapshot: ProfileSnapshot,
    target_browser: BrowserInfo,
    target_profile_name: str,
    target_crypto_ctx: CryptoContext,
    *,
    mode: Literal["overwrite", "merge", "new"] = "overwrite",
) -> WriteResult:
    """Write transformed snapshot to target browser profile."""
    ...

@dataclass
class WriteResult:
    success: bool
    target_profile_path: Path
    records_written: Dict[str, int]   # {"bookmarks": 247, "logins": 89, ...}
    errors: List[str]
```

## 3. Atomic Write Pattern

```python
def _atomic_write_sqlite(target_path: Path, write_fn: Callable[[sqlite3.Connection], None]):
    tmp_path = target_path.with_suffix(target_path.suffix + ".cpm_tmp")
    
    # Copy existing target to tmp (so we extend, not replace)
    if target_path.exists():
        shutil.copy2(target_path, tmp_path)
    
    conn = sqlite3.connect(tmp_path)
    try:
        conn.execute("BEGIN TRANSACTION")
        write_fn(conn)
        conn.commit()
    except Exception:
        conn.rollback()
        tmp_path.unlink(missing_ok=True)
        raise
    finally:
        conn.close()
    
    # Atomic rename
    os.fsync(tmp_path.open("rb").fileno())
    tmp_path.replace(target_path)


def _atomic_write_json(target_path: Path, data: dict):
    tmp_path = target_path.with_suffix(".cpm_tmp")
    with tmp_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    tmp_path.replace(target_path)
```

## 4. Process Management

```python
def _ensure_browser_closed(browser_id: str, *, auto_kill: bool = False):
    """Check if browser is running. Kill if user consents."""
    if not is_browser_running(browser_id):
        return
    
    if not auto_kill:
        raise BrowserRunningError(
            f"{browser_id} is currently running. "
            f"Please close it manually or use --auto-close flag."
        )
    
    process_name = SUPPORTED_BROWSERS[browser_id]["process_name"]
    subprocess.run(["pkill", "-f", process_name], timeout=10)
    
    # Wait for graceful exit
    for _ in range(10):
        if not is_browser_running(browser_id):
            return
        time.sleep(0.5)
    
    raise BrowserRunningError(f"Failed to close {browser_id}")
```

## 5. Tests

- Atomic write: kill process mid-write, verify target file not corrupted.
- Re-encryption integration with M03.
- Process detection mocked.
- Permission setting verified.

Coverage: ≥ 85%.

---

# M06 — CLI Interface

**Owner:** Antigravity
**Reviewer:** Claude Code
**Priority:** P0
**Estimated Effort:** 10 hours

## 1. Stack

- `click` for command parsing.
- `rich` for progress bars and formatted output.
- `questionary` for interactive prompts.

## 2. Commands

```
cpm list                         # List installed browsers
cpm inspect chrome --profile Default
cpm migrate                      # Interactive
cpm migrate --from chrome --to edge --profile Default --mode overwrite
cpm history                      # List backups
cpm rollback <backup_id>
cpm cleanup --older-than 30d
cpm doctor                       # Health check
cpm version
```

## 3. Output Examples

### list
```
Installed Chromium browsers:
  ✓ Chrome    v120.0.6099.71    /Users/.../Chrome           3 profiles
  ✓ Edge      v120.0.2210.61    /Users/.../Microsoft Edge   1 profile
  ✓ Brave     v1.61.114         /Users/.../Brave-Browser    2 profiles
  ✗ Arc       (not installed)
  ✗ Cốc Cốc   (not installed)
```

### migrate (interactive)
```
? Source browser:  [Chrome]
? Source profile:  [Default (215 MB, last used 2 days ago)]
? Target browser:  [Edge]
? Target profile:  [Default (existing - will create backup)]
? Mode:            [Overwrite]

Migration plan:
  Source:        Chrome / Default
  Target:        Edge / Default
  Backup:        ~/CPM_Backups/2026-05-01_14-30-22/
  Estimated:     247 bookmarks, 89 logins, 1.2GB cookies
  Expected time: ~45 seconds

? Proceed?  [Y/n]
```

### Progress
```
[1/8] Detecting browsers...                ✓ done
[2/8] Validating environment...            ✓ done
[3/8] Backing up Edge profile...           ████████░░  80%  124MB / 154MB
[4/8] Reading Chrome profile...            ✓ done
[5/8] Decrypting...                        ✓ done (89 passwords, 1247 cookies)
[6/8] Transforming for Edge...             ✓ done
[7/8] Writing to Edge...                   ████░░░░░░  40%
[8/8] Verifying...                         ✓ done

Migration complete in 47s.
Report saved to: ~/.cpm/logs/2026-05-01_14-30-22.log
```

## 4. UX Principles

- Always confirm destructive actions.
- Default to non-interactive flags failing fast nếu thiếu params.
- Color: green=success, yellow=warning, red=error.
- Verbose mode `-v` cho debug.

---

# M07 — Backup & Rollback

**Owner:** Antigravity
**Reviewer:** Claude Code
**Priority:** P0
**Estimated Effort:** 8 hours

## 1. Public API

```python
def backup_profile(
    browser: BrowserInfo,
    profile_name: str,
    metadata: dict = None,
) -> BackupRecord:
    """Create tar.gz backup with metadata. Returns backup ID."""
    ...

def list_backups() -> List[BackupRecord]:
    """List all backups in ~/CPM_Backups/."""
    ...

def restore_backup(backup_id: str) -> RestoreResult:
    """Extract backup to original location."""
    ...

def cleanup_backups(older_than_days: int = 30) -> List[str]:
    """Delete backups older than threshold."""
    ...

@dataclass
class BackupRecord:
    id: str                 # "2026-05-01_14-30-22_edge_default"
    timestamp: datetime
    browser_id: str
    profile_name: str
    size_bytes: int
    checksum_sha256: str
    backup_path: Path
    metadata: dict
```

## 2. Implementation

```python
def backup_profile(browser, profile_name, metadata=None):
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_id = f"{timestamp}_{browser.id}_{profile_name.lower()}"
    backup_dir = Path.home() / "CPM_Backups" / backup_id
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    profile_path = browser.user_data_path / profile_name
    archive_path = backup_dir / "profile.tar.gz"
    
    # Create tar.gz
    with tarfile.open(archive_path, "w:gz") as tar:
        tar.add(profile_path, arcname=profile_name)
    
    # Compute checksum
    checksum = hashlib.sha256(archive_path.read_bytes()).hexdigest()
    
    # Write metadata
    meta = {
        "id": backup_id,
        "timestamp": timestamp,
        "browser_id": browser.id,
        "profile_name": profile_name,
        "size_bytes": archive_path.stat().st_size,
        "checksum_sha256": checksum,
        **(metadata or {}),
    }
    (backup_dir / "metadata.json").write_text(json.dumps(meta, indent=2))
    
    # Permissions
    os.chmod(archive_path, 0o600)
    os.chmod(backup_dir / "metadata.json", 0o600)
    
    return BackupRecord(...)
```

## 3. Tests

- Backup → checksum verify → restore → compare original.
- Cleanup edge cases (no backups, all backups recent).
- Metadata corruption handled.

---

# M08 — Logger & Telemetry

**Owner:** Antigravity (impl) + Claude Code (sanitization rules)
**Reviewer:** Claude Code
**Priority:** P1
**Estimated Effort:** 6 hours

## 1. Sanitization Rules (Claude Code defines)

```python
SENSITIVE_KEYS = {
    "password", "password_value", "encrypted_value", "value",
    "cookie_value", "card_number", "cvv", "card_number_encrypted",
    "username_value", "auth_token", "session_id",
}

def sanitize(record: dict) -> dict:
    """Recursively replace sensitive values with [REDACTED]."""
    result = {}
    for key, value in record.items():
        if key.lower() in SENSITIVE_KEYS:
            result[key] = "[REDACTED]"
        elif isinstance(value, dict):
            result[key] = sanitize(value)
        elif isinstance(value, (list, tuple)):
            result[key] = [sanitize(v) if isinstance(v, dict) else v for v in value]
        else:
            result[key] = value
    return result
```

## 2. Logger Setup

```python
import structlog

def setup_logger(log_file: Path):
    structlog.configure(
        processors=[
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            sanitize_processor,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        ...
    )
```

## 3. Tests

- Verify sensitive keys redacted.
- Nested dicts handled.
- Logs are valid JSON.
- File rotation works.

Coverage: ≥ 90%.
