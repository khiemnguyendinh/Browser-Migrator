# Code Review Checklist

> Used by Claude Code khi review PR từ Antigravity. Copy checklist này vào mỗi PR review comment.

## Quick Triage (5 phút)

- [ ] PR có description rõ ràng và link tới spec/issue.
- [ ] PR size manageable (< 500 LOC). Nếu lớn hơn → request split.
- [ ] CI pass (lint, type check, tests).
- [ ] Branch up to date với main.

## Architecture & Design (15 phút)

- [ ] Implementation match spec trong `04_Module_Specs/`.
- [ ] Public APIs đúng signature đã agree.
- [ ] No deviation từ data flow trong `02_Technical_Architecture/`.
- [ ] Không import internals của module khác (`_*` prefixed).
- [ ] Dependency direction đúng (e.g., M02 không import từ M05).

## Security (CRITICAL — 20 phút)

- [ ] **No plaintext sensitive data trong logs.** grep PR cho `password`, `cookie_value`, `card_number`.
- [ ] **No hardcoded secrets** (API keys, passwords, etc.).
- [ ] **No network calls** trong Phase A. grep cho `requests`, `urllib`, `httpx`, `socket`, `http`.
- [ ] **Path validation** cho mọi user-input path (no traversal).
- [ ] **SQL parameterized queries** (không string format SQL).
- [ ] **File permissions** set correctly (backups: 600).
- [ ] **Atomic operations** cho file writes (tmp + rename pattern).
- [ ] **Memory hygiene** cho secrets (clear sau khi dùng nếu critical).
- [ ] **Browser process check** trước khi modify profile files.

## Code Quality (15 phút)

- [ ] Type hints cho mọi public function/method.
- [ ] Docstrings (Google style) cho public APIs.
- [ ] No `print()` statements (use logger).
- [ ] No commented-out code.
- [ ] No `TODO`/`FIXME` without issue link.
- [ ] Function length < 50 lines (refactor nếu dài).
- [ ] File length < 500 lines.
- [ ] No mutable default arguments.
- [ ] Error handling specific (not catch-all `except Exception`).
- [ ] Resources closed (use context managers).

## Tests (10 phút)

- [ ] Unit tests có cho mọi public function.
- [ ] Coverage ≥ 80% (M03: ≥ 95%).
- [ ] Edge cases covered:
  - [ ] Empty input
  - [ ] Invalid input
  - [ ] Permission errors
  - [ ] File not found
  - [ ] Corrupted data
- [ ] Tests deterministic (no random, no time-dependent).
- [ ] Tests fast (< 100ms each, ideally).
- [ ] Mocks used cho external deps (filesystem, subprocess, Keychain).
- [ ] Test names mô tả intent (`test_decrypt_returns_empty_for_empty_input` không phải `test_1`).

## Performance (5 phút)

- [ ] No N+1 queries.
- [ ] Streaming reads cho large files.
- [ ] No unnecessary copies of large data structures.
- [ ] Memory usage bounded.

## Documentation (5 phút)

- [ ] User-facing changes reflected trong README.
- [ ] Breaking changes noted in CHANGELOG.
- [ ] Spec updated nếu API thay đổi.

## Specific Module Checks

### M01 — Browser Detector
- [ ] Handle missing browsers gracefully.
- [ ] Process detection cross-platform (macOS specific OK).
- [ ] Profile enumeration không crash với weird folder names.

### M02 — Profile Reader
- [ ] SQLite open trong read-only mode.
- [ ] Encrypted blobs giữ nguyên `bytes` type.
- [ ] No decryption attempted (M03 only).
- [ ] Streaming cho large History tables.

### M03 — Keychain Decryptor (Claude Code self-review extra)
- [ ] No plaintext in logs (DEBUG, INFO, ERROR all levels).
- [ ] CryptoContext repr/str redacted.
- [ ] Re-encryption: plaintext stays in single function.
- [ ] Tests use fake keys, không real Keychain.
- [ ] grep module cho `password|secret|key` → only in test fixtures.

### M04 — Data Transformer
- [ ] Adapter pattern correctly implemented.
- [ ] No browser-specific logic outside adapters.
- [ ] Default behaviors safe (return source nếu không có transform).

### M05 — Profile Writer
- [ ] Atomic write pattern (tmp + fsync + rename).
- [ ] Browser process detected và handled.
- [ ] Transactions wrap multi-write operations.
- [ ] Permissions set on output files.

### M06 — CLI
- [ ] Confirm prompts cho destructive actions.
- [ ] Help text clear.
- [ ] Exit codes meaningful (0 success, non-zero error).
- [ ] Color output gracefully degrades khi no TTY.

### M07 — Backup & Rollback
- [ ] Backup checksum computed và stored.
- [ ] Metadata.json validates trước khi restore.
- [ ] Restore is atomic (or rollback on failure).
- [ ] Cleanup không xóa backup mới.

### M08 — Logger
- [ ] Sanitization applied trên ALL log records.
- [ ] Sensitive keys list comprehensive.
- [ ] Nested dicts/lists recursively sanitized.
- [ ] Log files have proper permissions.

## Final Check

- [ ] Manual smoke test: run code locally trên Mac, verify expected behavior.
- [ ] No regression in existing tests.
- [ ] PR description updated với "what changed" và "why".

## Decision

- **APPROVE:** All items checked.
- **REQUEST CHANGES:** Critical items unchecked. List them in review comment.
- **COMMENT:** Non-critical suggestions.

## Review Comment Template

```markdown
## Review Summary

### Architecture: ✓
[Brief comment]

### Security: ✓ / ⚠
[Critical findings if any]

### Quality: ✓
[Brief comment]

### Tests: ✓
Coverage: X%

### Required Changes
1. [Specific fix needed]
2. [Specific fix needed]

### Suggestions (non-blocking)
- [Optional improvement]

### Approval: APPROVE / REQUEST CHANGES
```
