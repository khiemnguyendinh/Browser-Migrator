# Handoff Protocol — Claude Code ↔ Antigravity

## 1. Tình Huống Handoff

Trong dự án CPM, có các loại handoff sau:

### Type A: Spec → Implementation
- Claude Code design interface trong `04_Module_Specs/` → Antigravity implement.
- **Modules áp dụng:** M02, M04, M05.

### Type B: Implementation → Review
- Antigravity submit PR → Claude Code review.
- **Áp dụng:** Mọi PR.

### Type C: Module Boundary
- M01 (Antigravity) cung cấp `BrowserInfo` → M02 (cả 2) consume.
- M02 (cả 2) produce `ProfileSnapshot` → M04 (cả 2) transform → M05 (cả 2) write.
- M03 (Claude Code) cung cấp crypto APIs → M02, M05 use.

## 2. Spec Handoff Protocol (Type A)

### Bước 1: Claude Code Hoàn Thành Spec

Spec phải có:
- Public API với type hints.
- Dataclasses định nghĩa.
- Implementation hints (không phải code chi tiết).
- Test cases cụ thể (input → expected output).
- Edge cases liệt kê.
- Performance requirements.

### Bước 2: Antigravity Đọc & Confirm

Antigravity reply trong daily log:
```
Confirmed spec M0X. Estimated 2 days. Will start Tuesday.
Questions: [if any]
```

Nếu có questions → Claude Code clarify trước khi implement.

### Bước 3: Implementation

Antigravity:
- Implement đúng public API.
- KHÔNG thay đổi signature mà không hỏi.
- Nếu phát hiện spec sai/thiếu → comment trong daily log, không tự fix.

### Bước 4: Review & Merge

Claude Code review theo `Code_Review_Checklist.md`.

## 3. PR Review Protocol (Type B)

### SLA
- Standard PR: review trong 24 giờ.
- Critical (M03 related): review trong 4 giờ.
- Hot fix: review trong 1 giờ.

### Review Levels

**Level 1 — Architecture Compliance**
- Code follows spec?
- Public API match interface đã define?
- No deviations từ architectural decisions?

**Level 2 — Security**
- No plaintext logging.
- No network calls (Phase A).
- Atomic operations đúng pattern.
- Input validation.

**Level 3 — Quality**
- Type hints đầy đủ.
- Tests coverage đủ.
- Edge cases handled.
- Performance acceptable.

**Level 4 — Style**
- Black + ruff clean.
- Naming conventions.
- File organization.

### Review Outcomes

- **APPROVE:** Merge ngay.
- **REQUEST CHANGES:** Liệt kê specific items cần fix. Antigravity fix → re-request review.
- **COMMENT (no block):** Suggestions không critical, optional fix.

### Antigravity Response to Review

- Within 4 hours: acknowledge feedback.
- Within 24 hours: push fixes.
- If disagree: comment với reasoning, không silent ignore.

## 4. Module Boundary Protocol (Type C)

### Interface Contracts

Mỗi module có **public API rõ ràng**. Module khác chỉ dùng public API, KHÔNG import internals.

```python
# GOOD
from cpm.m01_detector import detect_all_browsers, BrowserInfo

# BAD
from cpm.m01_detector._internal import _scan_apps_folder
```

### Data Flow Between Modules

| Producer | Output | Consumer |
|---|---|---|
| M01 | `BrowserInfo` | Orchestrator, M02, M05, M07 |
| M02 | `ProfileSnapshot` | M04, Orchestrator |
| M03 | `CryptoContext`, encrypt/decrypt fns | M02 (via Orchestrator), M05 (via Orchestrator) |
| M04 | Transformed `ProfileSnapshot` | M05 |
| M05 | `WriteResult` | Orchestrator |
| M07 | `BackupRecord` | Orchestrator |
| M08 | Logger instance | All modules |
| Orchestrator | `MigrationResult` | M06 (CLI) |

### Versioning Internal APIs

Phase A: không cần versioning. Phase C: nếu API stable, version `__api_version__`.

## 5. Conflict Resolution

### Loại 1: Spec Ambiguity

**Process:**
1. Antigravity flag trong PR comment hoặc daily log.
2. Claude Code clarify.
3. Update spec để reflect clarification (`04_Module_Specs/`).
4. Antigravity proceed.

### Loại 2: Implementation Disagreement

**Example:** Antigravity dùng `concurrent.futures`, Claude Code muốn `asyncio`.

**Process:**
1. Discuss trong PR comments.
2. Nếu impact > module local → Claude Code quyết định.
3. Nếu impact local thuần → Antigravity quyết định, document lý do.

### Loại 3: Architecture Disagreement

**Process:**
1. Antigravity propose alternative trong daily log.
2. Claude Code review trong 24h.
3. Nếu Claude Code disagree → giải thích lý do, decision is final.
4. Nếu Antigravity vẫn không đồng ý → escalate to Khiêm.

## 6. Knowledge Transfer

### Khi Module Done

Antigravity hoặc Claude Code (whoever owns module) phải:

1. Update module spec với "Implementation Notes" section ở cuối — document quirks, gotchas.
2. Update README user-facing docs nếu có user impact.
3. Thêm entry vào CHANGELOG.

### Khi Có Architectural Decision Mới

Document trong file mới:
`02_Technical_Architecture/decisions/ADR-XXX-{title}.md`

Format ADR (Architecture Decision Record):
```markdown
# ADR-001: Use subprocess for Keychain access

## Status
Accepted

## Context
[Why we needed to decide]

## Decision
[What we decided]

## Consequences
[Trade-offs]
```

## 7. Handoff Checklist (Phase A → Phase C)

Khi kết thúc Phase A và transition sang Phase C:

- [ ] All Phase A modules merged và tagged `v0.1`.
- [ ] All ADRs documented.
- [ ] Phase A retrospective notes archived.
- [ ] Open issues triaged for Phase C.
- [ ] Phase C kickoff brief (Khiêm) đã có.
