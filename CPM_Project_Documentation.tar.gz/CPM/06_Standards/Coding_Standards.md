# Coding Standards — CPM Project

## 1. Language & Version

- Python 3.11+
- Use new syntax: `match/case`, `X | Y` for union types, `Self` type, etc.

## 2. Style

### Formatting
- **Black** (line length 100, default).
- **Ruff** for linting (replaces flake8, isort).
- Run on save / pre-commit hook.

### Naming Conventions
- `snake_case` for variables, functions.
- `PascalCase` for classes.
- `UPPER_SNAKE` for constants.
- `_private` prefix for module-internal symbols.
- `__dunder__` only for Python protocol methods.

### Imports
```python
# Standard library
import os
import sys
from pathlib import Path
from typing import Optional

# Third-party
import click
from cryptography.hazmat.primitives import hashes

# Local
from cpm.m01_detector import BrowserInfo
from cpm.m08_logger import logger
```

Order: stdlib → 3rd party → local. Blank line between groups.

## 3. Type Hints (Mandatory)

```python
# GOOD
def read_profile(browser: BrowserInfo, profile_name: str) -> ProfileSnapshot:
    ...

# BAD
def read_profile(browser, profile_name):
    ...
```

- Use `Optional[X]` or `X | None` for nullable.
- Use `list[X]` not `List[X]` (Python 3.9+).
- Use `dict[str, X]` not `Dict[str, X]`.
- Mypy strict mode enabled in CI.

## 4. Docstrings

Google style:

```python
def decrypt_value(encrypted: bytes, ctx: CryptoContext) -> bytes:
    """Decrypt a single encrypted value using the provided crypto context.
    
    Args:
        encrypted: Raw encrypted bytes from SQLite blob (with version prefix).
        ctx: CryptoContext containing derived AES key.
    
    Returns:
        Plaintext bytes.
    
    Raises:
        InvalidEncryptedFormat: If input doesn't have v10/v11 prefix.
        DecryptionError: If decryption fails (wrong key, corrupted data).
    
    Example:
        >>> ctx = get_crypto_context("chrome")
        >>> plaintext = decrypt_value(b"v10\\x..." , ctx)
    """
    ...
```

## 5. Error Handling

### Custom Exceptions

```python
# cpm/exceptions.py
class CPMError(Exception):
    """Base exception for CPM."""

class BrowserNotFoundError(CPMError):
    """Browser not installed or not detected."""

class BrowserRunningError(CPMError):
    """Browser process is running, cannot proceed."""

class KeychainAccessError(CPMError):
    """Failed to access macOS Keychain."""

class DecryptionError(CPMError):
    """Failed to decrypt data."""

class CorruptedProfileError(CPMError):
    """Profile data is corrupted."""

# ... etc
```

### Patterns

```python
# GOOD - specific exception, useful message
try:
    key = get_master_key("chrome")
except KeychainAccessError as e:
    logger.error("keychain_access_failed", browser="chrome", error=str(e))
    raise

# BAD - generic exception swallow
try:
    key = get_master_key("chrome")
except Exception:
    pass

# GOOD - context cleanup with finally
ctx = None
try:
    ctx = get_crypto_context("chrome")
    return process(data, ctx)
finally:
    if ctx:
        clear_context(ctx)
```

## 6. Logging

```python
from cpm.m08_logger import logger

# Structured logs với key=value
logger.info("migration_started", source="chrome", target="edge")
logger.warning("profile_locked", browser="chrome", profile="Default")
logger.error("decryption_failed", error=str(e))

# DEBUG cho verbose info
logger.debug("processing_cookie", domain="example.com")  # NO value!
```

**Never log:**
- Passwords, cookie values, encrypted blobs.
- Full file paths với username.
- Stack traces với sensitive data.

## 7. Path Handling

```python
from pathlib import Path

# GOOD
config_dir = Path.home() / ".cpm"
profile_path = browser.user_data_path / "Default"

# BAD
config_dir = "/Users/khiem/.cpm"  # Hardcoded
profile_path = browser.user_data_path + "/Default"  # String concat
```

## 8. SQL

```python
# GOOD - parameterized
conn.execute(
    "SELECT * FROM cookies WHERE host_key = ?",
    (host_key,),
)

# BAD - injection risk
conn.execute(f"SELECT * FROM cookies WHERE host_key = '{host_key}'")
```

## 9. Resource Management

```python
# GOOD - context manager
with sqlite3.connect(db_path) as conn:
    conn.execute(...)

# GOOD - try/finally
conn = sqlite3.connect(db_path)
try:
    conn.execute(...)
finally:
    conn.close()

# BAD - no cleanup
conn = sqlite3.connect(db_path)
conn.execute(...)
# Forgot to close
```

## 10. Atomic File Operations

```python
import os
import tempfile
from pathlib import Path

def atomic_write(target: Path, data: bytes):
    """Write data atomically to target path."""
    tmp_fd, tmp_path = tempfile.mkstemp(
        dir=target.parent,
        prefix=f".{target.name}.",
        suffix=".tmp",
    )
    try:
        with os.fdopen(tmp_fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp_path, 0o600)
        Path(tmp_path).replace(target)
    except Exception:
        Path(tmp_path).unlink(missing_ok=True)
        raise
```

## 11. Constants

```python
# cpm/constants.py
KEYCHAIN_TIMEOUT_SECONDS = 30
PBKDF2_ITERATIONS = 1003
PBKDF2_SALT = b"saltysalt"
AES_KEY_SIZE = 16
AES_IV = b" " * 16
ENCRYPTION_VERSION_PREFIX = b"v10"

BACKUP_RETENTION_DAYS = 30
MAX_PROFILE_SIZE_MB = 5000
MIGRATION_TIMEOUT_SECONDS = 300
```

## 12. Dataclasses & Pydantic

Phase A: stdlib `dataclasses` only. Pydantic considered overhead.

```python
from dataclasses import dataclass, field
from typing import Optional

@dataclass(frozen=True, slots=True)
class BrowserInfo:
    id: str
    display_name: str
    version: Optional[str] = None
    profiles: list = field(default_factory=list)
```

`frozen=True` for immutability. `slots=True` for memory efficiency.

## 13. Async/Concurrency

Phase A: synchronous code. Migration is sequential, no need for async.

Phase C: có thể consider asyncio nếu UI requires.

## 14. Dependencies

### Production (`pyproject.toml`)
```toml
[project]
dependencies = [
    "click>=8.1",
    "cryptography>=42.0",
    "rich>=13.0",
    "structlog>=24.0",
    "questionary>=2.0",
]
```

### Development
```toml
[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-cov>=5.0",
    "pytest-mock>=3.0",
    "black>=24.0",
    "ruff>=0.4",
    "mypy>=1.10",
    "pre-commit>=3.0",
]
```

**Adding new dependency:** request approval Claude Code, justify in PR.

## 15. File Organization

```
src/cpm/
├── __init__.py
├── __main__.py            # python -m cpm entry
├── cli.py                 # M06 - Click commands
├── orchestrator.py        # Migration engine
├── exceptions.py          # All custom exceptions
├── constants.py           # Project-wide constants
├── m01_detector.py
├── m02_reader.py
├── m03_decryptor.py
├── m04_transformer.py
├── m05_writer.py
├── m07_backup.py
├── m08_logger.py
└── adapters/              # M04 per-browser adapters
    ├── __init__.py
    ├── base.py
    ├── chrome.py
    ├── edge.py
    ├── brave.py
    ├── coccoc.py
    └── arc.py

tests/
├── conftest.py            # Shared fixtures
├── fixtures/
│   └── profiles/          # Mini profile data
├── unit/
│   ├── test_m01_detector.py
│   ├── test_m02_reader.py
│   └── ...
└── integration/
    └── test_e2e_migration.py
```

## 16. Pre-commit Hook

`.pre-commit-config.yaml`:
```yaml
repos:
  - repo: https://github.com/psf/black
    hooks:
      - id: black
  - repo: https://github.com/astral-sh/ruff-pre-commit
    hooks:
      - id: ruff
        args: [--fix]
  - repo: https://github.com/pre-commit/mirrors-mypy
    hooks:
      - id: mypy
        additional_dependencies: [types-all]
```

Run: `pre-commit install` once after clone.
