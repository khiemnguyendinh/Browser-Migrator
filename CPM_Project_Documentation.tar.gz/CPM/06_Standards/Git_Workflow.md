# Git Workflow

## 1. Branching Model

```
main                      # Production-ready code
  ├── feature/m03-keychain     # Claude Code work
  ├── feature/m02-reader       # Co-work
  ├── impl/m01-detector        # Antigravity work
  └── docs/user-guide          # Documentation
```

### Branch Naming

| Prefix | Owner | Use Case |
|---|---|---|
| `feature/` | Claude Code | New module với architectural design |
| `impl/` | Antigravity | Implementation theo spec |
| `fix/` | Both | Bug fixes |
| `refactor/` | Both | Refactoring không add features |
| `docs/` | Both | Documentation only |
| `test/` | Both | Test additions/improvements |

### Naming Format

`{prefix}/m{number}-{short-description}`

Examples:
- `feature/m03-keychain-decryptor`
- `impl/m01-browser-detection`
- `fix/m07-backup-checksum-mismatch`

## 2. Commit Messages

Conventional Commits format:

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

- `feat`: New feature.
- `fix`: Bug fix.
- `docs`: Documentation only.
- `style`: Formatting (no code change).
- `refactor`: Code change without feature/fix.
- `test`: Adding/updating tests.
- `chore`: Build, deps, tooling.
- `perf`: Performance improvement.
- `security`: Security fix.

### Scope

Module abbreviation: `m01`, `m02`, `m03`, ..., `cli`, `core`, `docs`.

### Examples

```
feat(m01): add browser version detection from Info.plist

Reads CFBundleShortVersionString from app bundle.
Falls back to "unknown" if Info.plist missing.

Closes #12
```

```
fix(m07): handle missing metadata.json gracefully

Previously crashed on KeyError. Now returns None and logs warning.
```

```
security(m08): redact additional sensitive keys

Added: card_number, cvv, auth_token, session_id
```

### Rules

- Subject line: imperative mood, ≤ 72 chars.
- Body: explain "why" not "what" (code shows what).
- No "WIP" commits in main/PR-ready branches.

## 3. Pull Request Workflow

### 3.1 Before Opening PR

```bash
# Sync with main
git checkout main
git pull
git checkout your-branch
git rebase main

# Run checks locally
ruff check src/ tests/
black --check src/ tests/
mypy src/
pytest tests/ --cov=src

# Squash WIP commits if needed
git rebase -i HEAD~N
```

### 3.2 PR Title

Same format as commit subject:
```
feat(m01): add browser version detection
```

### 3.3 PR Description Template

```markdown
## Summary
[1-2 sentences what changed and why]

## Module
M0X — [Module Name]

## Type
- [ ] New feature
- [ ] Bug fix
- [ ] Refactoring
- [ ] Documentation
- [ ] Tests

## Spec Reference
Link to `04_Module_Specs/M0X_*.md`

## Checklist
- [ ] Code follows architecture spec
- [ ] Type hints added
- [ ] Tests added (coverage: X%)
- [ ] Lint pass (ruff, black)
- [ ] Type check pass (mypy)
- [ ] No sensitive data logged
- [ ] No network calls (Phase A)
- [ ] Documentation updated

## Testing
[How you tested this]

## Screenshots/Output
[If applicable]

## Notes for Reviewer
[Anything reviewer should know]
```

### 3.4 Review Process

1. Author requests review từ Claude Code.
2. Claude Code reviews trong SLA (24h standard, 4h critical).
3. Author addresses feedback.
4. Claude Code approves → author merges.

### 3.5 Merge Strategy

- **Squash merge** cho feature/impl branches → main (clean history).
- **Merge commit** cho release branches (preserve detail).
- **Rebase** cho hotfix nhỏ.

Squash commit message format: same as PR title.

## 4. .gitignore

```
# Python
__pycache__/
*.py[cod]
*.so
.venv/
venv/
*.egg-info/
.pytest_cache/
.mypy_cache/
.ruff_cache/
.coverage
htmlcov/
dist/
build/

# IDE
.vscode/
.idea/
*.swp

# OS
.DS_Store
Thumbs.db

# Project specific
~/CPM_Backups/
.cpm/
*.log

# Secrets
.env
.env.local
*.pem
*.key
```

## 5. Tags & Releases

### Semantic Versioning

```
v{MAJOR}.{MINOR}.{PATCH}
```

Phase A target:
- `v0.1.0` — Internal MVP release.
- `v0.1.1`, `v0.1.2` — Patches.

Phase C:
- `v0.2.0` — GUI added.
- `v1.0.0` — Public release.

### Tagging

```bash
git tag -a v0.1.0 -m "Phase A MVP release"
git push origin v0.1.0
```

### CHANGELOG.md

Update mỗi release:
```markdown
## [v0.1.0] - 2026-05-15
### Added
- Initial CLI with migrate, list, inspect, history, rollback, cleanup commands
- Support for Chrome, Edge, Brave, Cốc Cốc, Arc
- Backup/restore with checksum verification

### Security
- All sensitive data redacted in logs
- Atomic file writes
- Memory hygiene for crypto operations
```

## 6. Daily Git Hygiene

### Pull Before Work

```bash
git checkout main
git pull
git checkout your-branch
git rebase main  # or merge if preferred
```

### Commit Often, Push Daily

- Commit logical units (1 commit = 1 idea).
- Push to remote at end of day even if WIP (backup).

### Don't Commit Sensitive Data

Pre-commit hook should catch:
- Files matching `.env`, `*.key`, `*.pem`.
- Strings matching common secret patterns (API keys).

If committed by accident:
```bash
# Remove from history (if not pushed)
git reset --soft HEAD~1
# Or rewrite if pushed (WARNING: coordinate with team)
git filter-branch ...
```

## 7. Conflict Resolution

```bash
git rebase main
# Conflicts appear
# Edit files
git add resolved-files
git rebase --continue
```

If unsure → ping Claude Code before force-push.

## 8. Useful Aliases

`~/.gitconfig`:
```ini
[alias]
    co = checkout
    br = branch
    st = status
    ci = commit
    last = log -1 HEAD
    visual = !gitk
    lg = log --oneline --graph --decorate --all
```
