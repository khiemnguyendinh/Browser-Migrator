# Testing Strategy — CPM Project

## 1. Testing Pyramid

```
              ┌──────────────┐
              │  E2E Tests   │  ~5 tests   (slow, real env)
              │   (Day 9-10) │
              └──────────────┘
            ┌──────────────────┐
            │ Integration Tests│  ~15 tests  (medium, mocked deps)
            │  (Per module)    │
            └──────────────────┘
        ┌──────────────────────────┐
        │      Unit Tests          │  ~150+ tests (fast, isolated)
        │  (Mọi public function)   │
        └──────────────────────────┘
```

## 2. Coverage Targets

| Module | Min Coverage | Lý do |
|---|---|---|
| M03 (Keychain) | 95% | Security-critical |
| M02, M04, M05 | 85% | Core business logic |
| M01, M07 | 85% | Data integrity |
| M08 (Logger) | 90% | Sanitization phải đúng |
| M06 (CLI) | 70% | UI layer, manual test bù |
| Orchestrator | 90% | State machine critical |
| **Overall** | **≥ 80%** | Phase A acceptance criteria |

## 3. Test Categories

### 3.1 Unit Tests (`tests/unit/`)

**Definition:** Test 1 function/class in isolation. All external deps mocked.

**Examples:**
```python
# tests/unit/test_m03_decryptor.py
def test_derive_aes_key_correct_length():
    key = _derive_aes_key(b"master_key_bytes")
    assert len(key) == 16

def test_decrypt_value_with_v10_prefix(mock_crypto_ctx):
    encrypted = _encrypt_test_helper(b"plaintext", mock_crypto_ctx)
    result = decrypt_value(encrypted, mock_crypto_ctx)
    assert result == b"plaintext"

def test_decrypt_invalid_format_raises():
    ctx = _make_test_ctx()
    with pytest.raises(InvalidEncryptedFormat):
        decrypt_value(b"xx", ctx)
```

**Run command:**
```bash
pytest tests/unit/ -v
```

**Speed target:** < 50ms per test, < 30s total.

### 3.2 Integration Tests (`tests/integration/`)

**Definition:** Test multiple modules working together. Use real filesystem, mock external services (Keychain, browser processes).

**Examples:**
```python
# tests/integration/test_read_decrypt_flow.py
def test_read_chrome_profile_and_decrypt(tmp_path, mock_keychain):
    # Setup mock Chrome profile
    profile = create_mock_chrome_profile(tmp_path)
    mock_keychain.set("Chrome Safe Storage", b"test_master_key")
    
    # Execute
    browser_info = BrowserInfo(id="chrome", user_data_path=profile.parent, ...)
    snapshot = read_profile(browser_info, "Default")
    ctx = get_crypto_context("chrome")
    
    # Verify cookies decrypt successfully
    for cookie in snapshot.cookies:
        plaintext = decrypt_value(cookie.encrypted_value, ctx)
        assert plaintext  # Non-empty


# tests/integration/test_backup_restore.py
def test_backup_then_restore_recovers_original(tmp_path, mock_browser):
    profile_path = tmp_path / "Default"
    create_mock_profile(profile_path, files={"Bookmarks": b'{"v":1}'})
    
    backup = backup_profile(mock_browser, "Default")
    
    # Modify profile (simulate failed migration)
    (profile_path / "Bookmarks").write_bytes(b"corrupted")
    
    restore_backup(backup.id)
    
    assert (profile_path / "Bookmarks").read_bytes() == b'{"v":1}'
```

**Run command:**
```bash
pytest tests/integration/ -v
```

**Speed target:** < 5s per test, < 2 min total.

### 3.3 End-to-End Tests (`tests/e2e/`)

**Definition:** Full migration pipeline. Real filesystem, real subprocess. Run on actual Mac with browsers installed.

**Examples:**
```python
# tests/e2e/test_chrome_to_edge_migration.py
@pytest.mark.e2e
@pytest.mark.requires_chrome
@pytest.mark.requires_edge
def test_full_migration_chrome_to_edge():
    # Pre-condition: Chrome and Edge installed, both closed
    
    result = subprocess.run(
        ["python", "-m", "cpm", "migrate", "--from", "chrome", "--to", "edge",
         "--profile", "Default", "--mode", "new", "--yes"],
        capture_output=True, text=True, timeout=120,
    )
    
    assert result.returncode == 0
    assert "Migration complete" in result.stdout
    
    # Verify Edge profile has data
    edge_profile = Path.home() / "Library/Application Support/Microsoft Edge/Profile 1"
    assert (edge_profile / "Bookmarks").exists()
    assert (edge_profile / "History").exists()
    
    # Cleanup
    shutil.rmtree(edge_profile)
```

**Run command:**
```bash
pytest tests/e2e/ -v -m e2e
```

**Speed target:** < 60s per test. Run only Day 9-10 hoặc on-demand.

### 3.4 Security Tests (`tests/security/`)

**Definition:** Verify security controls. Mỗi ST-XX trong threat model.

**Examples:**
```python
# tests/security/test_no_plaintext_in_logs.py
def test_full_migration_logs_have_no_plaintext(tmp_path, capture_logs):
    run_full_migration(...)
    
    log_content = capture_logs.read_text()
    
    # No common password patterns
    assert "password=" not in log_content.lower()
    assert "cookie_value=" not in log_content
    
    # Specific test password should not appear
    assert "MyTestPassword123" not in log_content


# tests/security/test_no_network_calls.py
def test_phase_a_makes_no_network_calls(monkeypatch):
    """Verify zero network calls in Phase A code."""
    socket_calls = []
    real_socket = socket.socket
    
    def mock_socket(*args, **kwargs):
        socket_calls.append((args, kwargs))
        return real_socket(*args, **kwargs)
    
    monkeypatch.setattr(socket, "socket", mock_socket)
    
    run_full_migration(...)
    
    assert len(socket_calls) == 0


# tests/security/test_path_traversal_rejected.py
def test_profile_name_traversal_rejected():
    with pytest.raises(InvalidInputError):
        read_profile(browser_info, "../../etc/passwd")


# tests/security/test_backup_permissions.py
def test_backup_files_have_600_permissions(tmp_path, mock_browser):
    backup = backup_profile(mock_browser, "Default")
    
    archive_path = backup.backup_path / "profile.tar.gz"
    mode = stat.S_IMODE(archive_path.stat().st_mode)
    assert mode == 0o600
```

## 4. Test Fixtures

### 4.1 Shared Fixtures (`tests/conftest.py`)

```python
import pytest
from pathlib import Path

@pytest.fixture
def mock_chrome_profile(tmp_path: Path) -> Path:
    """Create a minimal Chrome profile structure."""
    profile = tmp_path / "Default"
    profile.mkdir()
    
    # Bookmarks
    bookmarks = {
        "roots": {
            "bookmark_bar": {
                "children": [
                    {"id": "1", "name": "Google", "url": "https://google.com",
                     "type": "url", "date_added": "13350000000000000"}
                ],
                "id": "0", "name": "Bookmarks bar", "type": "folder",
                "date_added": "13350000000000000",
            },
            "other": {"children": [], "id": "2", "name": "Other",
                      "type": "folder", "date_added": "13350000000000000"},
            "synced": {"children": [], "id": "3", "name": "Synced",
                       "type": "folder", "date_added": "13350000000000000"},
        },
        "version": 1,
    }
    (profile / "Bookmarks").write_text(json.dumps(bookmarks))
    
    # History (SQLite)
    conn = sqlite3.connect(profile / "History")
    conn.execute("""
        CREATE TABLE urls (
            id INTEGER PRIMARY KEY,
            url TEXT, title TEXT,
            visit_count INTEGER, typed_count INTEGER,
            last_visit_time INTEGER
        )
    """)
    conn.execute(
        "INSERT INTO urls VALUES (1, 'https://google.com', 'Google', 5, 0, 13350000000000000)"
    )
    conn.commit()
    conn.close()
    
    # ... Login Data, Cookies, Web Data với data tối thiểu
    
    return profile


@pytest.fixture
def mock_keychain(monkeypatch):
    """Mock subprocess calls to /usr/bin/security."""
    keychain_data = {}
    
    def fake_run(args, **kwargs):
        if "find-generic-password" in args:
            service_idx = args.index("-s") + 1
            service = args[service_idx]
            if service in keychain_data:
                return subprocess.CompletedProcess(
                    args=args, returncode=0,
                    stdout=keychain_data[service].decode(),
                    stderr="",
                )
            return subprocess.CompletedProcess(args=args, returncode=44, stdout="", stderr="not found")
    
    monkeypatch.setattr(subprocess, "run", fake_run)
    
    class Helper:
        def set(self, service, value):
            keychain_data[service] = value
    
    return Helper()


@pytest.fixture
def mock_browser():
    """Generic BrowserInfo for testing."""
    return BrowserInfo(
        id="chrome",
        display_name="Google Chrome",
        version="120.0",
        user_data_path=Path("/tmp/test_chrome"),
        profiles=[],
        is_running=False,
    )
```

### 4.2 Per-Module Fixtures

Đặt trong `tests/unit/test_mXX.py` nếu specific cho module đó.

## 5. Test Data Strategy

### Don't Commit Real Profiles

KHÔNG commit:
- Real Chrome/Edge profiles (chứa data thật).
- Real Keychain dumps.
- Real cookies/passwords.

### Use Synthetic Data

```python
# tests/fixtures/profiles/mini_chrome/
# - Bookmarks (10 bookmarks)
# - History (100 history entries, all to fake.example.com)
# - Login Data (5 logins với username "test_user_X", password test data)
# - Cookies (10 cookies, all encrypted with known test key)
```

### Test Master Keys

```python
# tests/conftest.py
TEST_MASTER_KEY = b"this_is_test_key_only_no_real"  # Never use in production
```

## 6. CI Configuration (Phase C)

`.github/workflows/test.yml`:
```yaml
name: Tests
on: [push, pull_request]

jobs:
  unit-and-integration:
    runs-on: macos-latest
    strategy:
      matrix:
        python-version: ['3.11', '3.12']
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - run: pip install -e ".[dev]"
      - run: ruff check src/ tests/
      - run: black --check src/ tests/
      - run: mypy src/
      - run: pytest tests/unit/ tests/integration/ --cov=src --cov-fail-under=80
      - uses: codecov/codecov-action@v4

  e2e:
    runs-on: macos-latest
    # Only on PR to main, manual trigger
    if: github.event_name == 'pull_request' && github.base_ref == 'main'
    steps:
      - uses: actions/checkout@v4
      - run: brew install --cask google-chrome microsoft-edge brave-browser
      - run: pytest tests/e2e/ -v -m e2e
```

## 7. Manual Test Plan (Day 9-10)

### Test Matrix

| Source | Target | Profile | Mode | Expected |
|---|---|---|---|---|
| Chrome | Edge | Default | new | Pass |
| Chrome | Edge | Default | overwrite | Pass với backup |
| Chrome | Edge | Default | merge | Pass, no duplicates |
| Chrome | Brave | Profile 1 | new | Pass |
| Chrome | Cốc Cốc | Default | new | Pass |
| Edge | Chrome | Default | new | Pass |
| Brave | Edge | Default | new | Pass |
| Cốc Cốc | Chrome | Default | new | Pass |

### Manual Verification Steps

After each migration:
1. Open target browser.
2. Verify bookmarks appear.
3. Visit Gmail, verify auto-login (cookie session).
4. Visit a saved password site, verify autofill.
5. Check History tab, verify entries present.
6. Run `cpm rollback` → verify original restored.

## 8. Performance Tests

```python
# tests/performance/test_migration_speed.py
@pytest.mark.performance
def test_500mb_profile_migrates_under_60s(large_profile):
    start = time.perf_counter()
    run_migration(large_profile, ...)
    elapsed = time.perf_counter() - start
    assert elapsed < 60, f"Took {elapsed}s, target < 60s"


def test_memory_usage_under_200mb(large_profile):
    process = psutil.Process()
    baseline = process.memory_info().rss
    
    run_migration(large_profile, ...)
    
    peak = process.memory_info().rss
    delta_mb = (peak - baseline) / 1024 / 1024
    assert delta_mb < 200, f"Used {delta_mb}MB, target < 200MB"
```

## 9. Test-Driven Development (TDD)

**Recommended cho M03 (Keychain):**

1. Write failing test cho behavior cần.
2. Implement minimal code để pass.
3. Refactor.
4. Repeat.

**Lý do:** Module security-critical, TDD ép viết test cases edge cases trước.

## 10. Test Naming Convention

```python
def test_{action}_{condition}_{expected_result}():
    ...

# Examples:
def test_decrypt_value_with_valid_input_returns_plaintext():
def test_decrypt_value_with_invalid_format_raises_error():
def test_backup_profile_creates_archive_with_metadata():
def test_migrate_when_target_exists_creates_backup():
```

## 11. Failure Investigation

Khi test fail in CI hoặc local:

1. Run failing test isolated: `pytest tests/path/to/test.py::test_name -v`.
2. Use `pytest -x` to stop on first failure.
3. Use `pytest --pdb` để drop into debugger.
4. Check logs: `pytest -s` to show stdout.

## 12. Test Health Metrics

Track over time:
- Total tests count.
- Coverage %.
- Average test runtime.
- Flaky tests (fail randomly) — fix or quarantine.

Phase A target:
- 0 flaky tests.
- Test suite runs trong < 3 phút (excluding E2E).
- Coverage báo cáo trong mỗi PR.
